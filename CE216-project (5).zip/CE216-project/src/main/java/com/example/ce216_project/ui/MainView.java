package com.example.ce216_project.ui;

public class MainView {
}
